﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCMUSICSTORE.Models;

public class Artist
{
    [Key]
[DatabaseGenerated(System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption.None)]
public int ArtistId { get; set; }

[Column(TypeName = "varchar(50)")]
public string ArtistName { get; set; }
public List<Album> Albums { get; set; }

}
