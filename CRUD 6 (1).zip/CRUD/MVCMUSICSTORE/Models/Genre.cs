﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCMUSICSTORE.Models;

public class Genre
{
    [Key]       [DatabaseGenerated(System.ComponentModel.DataAnnotations.Schema.
DatabaseGeneratedOption.None)]
public int GenreId { get; set; }

[Column(TypeName="varchar(50)")]
public string GenreName { get; set; }

[Column(TypeName = "varchar(50)")]
public string Description { get; set; }
public List<Album> Albums { get; set; }

}
