﻿using Microsoft.EntityFrameworkCore;
using MVCMUSICSTORE.Models;

namespace MvcMusicStore.Models;
 
public class MusicStoreContext : DbContext
{
    public MusicStoreContext()
    {
    }

    public MusicStoreContext(DbContextOptions<MusicStoreContext> options) : base(options) { }
       
      public DbSet<Genre> AllGenres { get; set; }
      public DbSet<Album> AllAlbums { get; set; }
      public DbSet<Artist> AllArtists { get; set; }
 
}
 