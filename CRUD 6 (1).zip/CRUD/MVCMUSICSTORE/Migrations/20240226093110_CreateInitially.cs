﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MVCMUSICSTORE.Migrations
{
    /// <inheritdoc />
    public partial class CreateInitially : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AllArtists",
                columns: table => new
                {
                    ArtistId = table.Column<int>(type: "int", nullable: false),
                    ArtistName = table.Column<string>(type: "varchar", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AllArtists", x => x.ArtistId);
                });

            migrationBuilder.CreateTable(
                name: "AllGenres",
                columns: table => new
                {
                    GenreId = table.Column<int>(type: "int", nullable: false),
                    GenreName = table.Column<string>(type: "varchar", nullable: false),
                    Description = table.Column<string>(type: "varchar", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AllGenres", x => x.GenreId);
                });

            migrationBuilder.CreateTable(
                name: "AllAlbums",
                columns: table => new
                {
                    Title = table.Column<string>(type: "varchar", nullable: false),
                    Price = table.Column<double>(type: "float", nullable: false),
                    AlbumArtUrl = table.Column<string>(type: "varchar", nullable: false),
                    GenreId = table.Column<int>(type: "int", nullable: false),
                    ArtistId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AllAlbums", x => x.Title);
                    table.ForeignKey(
                        name: "FK_AllAlbums_AllArtists_ArtistId",
                        column: x => x.ArtistId,
                        principalTable: "AllArtists",
                        principalColumn: "ArtistId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AllAlbums_AllGenres_GenreId",
                        column: x => x.GenreId,
                        principalTable: "AllGenres",
                        principalColumn: "GenreId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AllAlbums_ArtistId",
                table: "AllAlbums",
                column: "ArtistId");

            migrationBuilder.CreateIndex(
                name: "IX_AllAlbums_GenreId",
                table: "AllAlbums",
                column: "GenreId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AllAlbums");

            migrationBuilder.DropTable(
                name: "AllArtists");

            migrationBuilder.DropTable(
                name: "AllGenres");
        }
    }
}
