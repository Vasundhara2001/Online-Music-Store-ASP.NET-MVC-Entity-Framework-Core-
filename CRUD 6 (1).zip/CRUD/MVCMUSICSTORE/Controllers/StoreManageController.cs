﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MvcMusicStore.Models;
using System.Data;
 
namespace MVCMUSICSTORE
{
    public class StoreManagerController : Controller
    {
        MusicStoreContext context;
        public StoreManagerController(DbContextOptions<MusicStoreContext> options){
 
            context=  new MusicStoreContext(options); }
        public IActionResult Index()
        {
           
 
            return View(context.AllAlbums.Include("Artist").Include("Genre").ToList());
        }

        public ActionResult CreateNewAlbum()
{
            return View();
}

[HttpPost]
public ActionResult CreateNewAlbum(MVCMUSICSTORE.Models.Album a)
{
            context.AllAlbums.Add(a);
            context.SaveChanges();
            return RedirectToAction("Index");
}
public ActionResult EditAlbum(string title)
{
var albumtoedit = 
context.AllAlbums.Include("Artist").
Include("Genre").Where(a => a.Title == title).SingleOrDefault();
            return View(albumtoedit);
}

[HttpPost]
      public ActionResult EditAlbum(MVCMUSICSTORE.Models.Album a)
      {
            
            context.Entry(a).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
      }

      public ActionResult DeleteAlbum(string title)
{
            var albumtodelete = context.AllAlbums.Where(a => a.Title 
				== title).SingleOrDefault();
            context.AllAlbums.Remove(albumtodelete);
            context.SaveChanges();
            return RedirectToAction("Index");
}







    }
}