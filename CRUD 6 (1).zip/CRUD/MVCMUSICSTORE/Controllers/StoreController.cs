using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MvcMusicStore.Models;
using MVCMUSICSTORE.Models;
// using MVCMUSICSTORE.Models;
namespace MVCMUSICSTORE.Controllers;

public class StoreController : Controller
{
    MusicStoreContext context; 

      public StoreController(DbContextOptions<MusicStoreContext> options){ 

            context=  new MusicStoreContext(options); 

      } 
    public ActionResult Index()
{
	var genres = context.AllGenres.ToList(); 

return View(genres); 
      }

        
public ActionResult Browse(string genre)
{
var genreModel = context.AllGenres.Include("Albums").Where(g =>  

g.GenreName == genre).Single(); 

return View(genreModel);
}


        
public ActionResult Details(string id)
{
	var album = context.AllAlbums.Find(id);
return View(album);

}




}